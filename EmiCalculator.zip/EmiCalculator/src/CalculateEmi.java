

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CalculateEmi")
public class CalculateEmi extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    public CalculateEmi() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		double amount = Double.parseDouble(req.getParameter("pAmount"));
		int time = Integer.parseInt(req.getParameter("month"));
		double rate = Double.parseDouble(req.getParameter("rate"));
		double emi = 0.0;
		rate = rate / (12 * 100); 
        time = time * 12; 
        emi = (amount * rate * (double)Math.pow(1 + rate, time))  
                / (double)(Math.pow(1 + rate, time) - 1);
        EMI data = new EMI(rate, emi);
		req.setAttribute("emi", data);
		req.getRequestDispatcher("/emi.jsp").forward(req,resp);
	}

}
