
public class EMI {
	private double intererstRate;
	private double amount;
	public EMI(double intererstRate, double amount) {
		super();
		this.intererstRate = intererstRate;
		this.amount = amount;
	}
	public double getIntererstRate() {
		return intererstRate;
	}
	public double getAmount() {
		return amount;
	}
	
	
}
